$(function(){
    var option={

    };
    var lineCharts = document.getElementById("barCharts");
    lineCharts.setOption(option);
});